#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>


#define PORT 4444
#define buffer_size 1000

int main(int argc, char const *argv[])
{
    int server_fd, new_sock;
    struct sockaddr_in address;
    //this is address to bind socket to
    

    //creating socket
    //server_fd contains the file descriptor of the socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1)
    {
        perror("Webclient not created successfully");
        return 1;
    }
    //client created successfully

    //this variable stores the size of address
    int addrlen = sizeof(address);

    //Address struct gets info added to it
    address.sin_family = AF_INET;
    address.sin_port = htons(PORT);
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    //sin_family is always set to AF_INET, sin_port contains the port in network byte order.

    
    //Incoming connections are accepted via this statement
    if(connect(server_fd, (struct sockaddr*) &address, (socklen_t) sizeof(address)) == -1)
    {
        perror("Error in connection from client side");
        exit(0);
    }
    //connection has been established at this stage

    char buffer1[buffer_size];//for received messages
    char buffer2[buffer_size];//for sending messages

    read(server_fd,buffer1,buffer_size); //initial hello message from server
    printf("S: %s",buffer1);

    //Entering your name
    memset(buffer2, '\0', sizeof(buffer2));
    printf("C: ");
    scanf("%[^\n]s\n",buffer2);

    //Sending your name
    send(server_fd,buffer2, strlen(buffer2),0);

    //Receiving the response from the server based on the first letter of your name
    memset(buffer1, '\0', sizeof(buffer1));
    read(server_fd,buffer1,buffer_size);
    printf("S: %s",buffer1);

    //if there's an error message we send back a "."
    if(strcmp(buffer1, "500 ERROR\n") == 0) 
    {
        send(server_fd, ".", strlen("."), 0);
        printf("C: .\n");
    }

    else //normal operation, we receive messages from client
    {
        int flag=1;
        //if we reach here it means no error message
        do
        {
        //client sends message 
        memset(buffer2, '\0', sizeof(buffer2));
        printf("C: ");
        scanf("\n%[^\n]s\n",buffer2);
        send(server_fd, buffer2, strlen(buffer2),0);

        if(strcmp(buffer2,".")==0) //so the input is . 
        {
            flag=0;
        }

        }while(flag);
    }

    memset(buffer1, '\0', sizeof(buffer1)); //we want thank you message
    read(server_fd , buffer1 , buffer_size);
    printf("S: %s",buffer1);



    //Closing connection
    close(server_fd);


    return 0;
}
