Open two terminals. In one of them run the following two commands:
gcc -o server server.c
gcc -o client client.c

2. Type ./server in the first terminal and hit enter. This will make the server up and running.
3. Type ./client in the OTHER terminal and hit enter. This will start the client up. Make sure you run the server first.

Now the first terminal runs your server, the second terminal runs your client and a connection has been established. 
The server will now ask the client to enter the name.
