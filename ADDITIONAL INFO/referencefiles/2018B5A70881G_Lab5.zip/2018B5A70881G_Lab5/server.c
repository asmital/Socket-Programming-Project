#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>


#define PORT 4444
#define buffer_size 1000

int main(int argc, char const *argv[])
{
    int server_fd, new_sock;
    struct sockaddr_in address;
    //this is address to bind socket to
    

    //creating socket
    //server_fd contains the file descriptor of the socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1)
    {
        perror("Webserver not created successfully");
        return 1;
    }
    //socket created successfully

    //this variable stores the size of address
    int addrlen = sizeof(address);

    //Address struct gets info added to it
    address.sin_family = AF_INET;
    address.sin_port = htons(PORT);
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    //sin_family is always set to AF_INET, sin_port contains the port in network byte order.

    //Binding the socket to the address
    if (bind(server_fd, (struct sockaddr *)&address, addrlen) != 0)
    {
        perror("No successful binding!"); //if it didnt bind successfully
        return 1;
    }

    //The listener for the socker listens for connections
    if (listen(server_fd, 1) != 0)
    {
        perror("Listener failure"); //in case of failure
        return 1;
    };

    //Incoming connections are accepted via this statement
    new_sock = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);

    //In case of error
    if (new_sock < 0)
    {
        perror("Failed connections!");
        return 1;
    }
    //connection has been established at this stage

    char buffer[buffer_size]; //string for the received message from client
    char str1[100] = "Hello, what is your name?\n";
    char str2[100] = "200 OK\n";
    char str3[100] = "500 ERROR\n";
    char str4[1100]; //thanks message
    //handy strings to display messages

    printf("S: %s", str1);
    if((send(new_sock, str1, strlen(str1)+1, 0)) == -1) {
        perror("Error in sending hi message");
        return 0;
    } 
    //Hi message has now been sent

    //We now need to receive the name 
    read(new_sock, buffer, buffer_size);
    printf("C: %s\n", buffer);
    sprintf(str4, "Thank you, %s\n", buffer);

    //We check the first letter of the name now 

    if(buffer[0]>= 'A' && buffer[0]<= 'Z') 
    {   
        //uppercase letter, good to go
        printf("S: %s", str2);
        if((send(new_sock, str2, strlen(str2)+1, 0)) == -1) 
        {
            perror("Error in sending 200 OK message");
            return 0;
        } 
    }
    else {
        //NOT uppercase letter
        printf("S: %s", str3);
        if((send(new_sock, str3, strlen(str3)+1, 0)) == -1) 
        {
            perror("Error in sending 500 ERROR message");
            return 0;
        } 
    }
    //we can start accepting client input now
    do {
        //clear the buffer first
        memset(buffer, '\0', sizeof(buffer));
        read(new_sock , buffer , buffer_size);
        printf("C: %s\n", buffer);

    }
    while(strcmp(buffer, ".")); //while we dont get a . character, we accept input


    //now we have received a . character from the client
    //we must now send a thank you message and close the connection


    printf("S: %s", str4);
    if((send(new_sock, str4, strlen(str4)+1, 0)) == -1) 
        {
            perror("Error in thank you message message");
            return 0;
        }  




    //Closing connection
    close(new_sock);


    return 0;
}
